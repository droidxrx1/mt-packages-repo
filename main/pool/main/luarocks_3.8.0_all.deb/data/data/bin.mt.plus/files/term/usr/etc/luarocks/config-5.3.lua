-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/data/data/bin.mt.plus/files/term/usr" };
}
variables = {
   LUA_DIR = "/data/data/bin.mt.plus/files/term/usr";
   LUA_INCDIR = "/data/data/bin.mt.plus/files/term/usr/include/lua5.3";
   LUA_BINDIR = "/data/data/bin.mt.plus/files/term/usr/bin";
}
