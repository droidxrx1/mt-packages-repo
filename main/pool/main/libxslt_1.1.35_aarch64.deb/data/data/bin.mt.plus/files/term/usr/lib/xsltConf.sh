#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/bin.mt.plus/files/term/usr/lib"
XSLT_LIBS="-lxslt -L/data/data/bin.mt.plus/files/term/usr/lib -lxml2 -lz -llzma -liconv -lm "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/data/data/bin.mt.plus/files/term/usr/include"
MODULE_VERSION="xslt-1.1.35"
