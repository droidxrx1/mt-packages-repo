require 'service.telemetry'
local service = require 'service.service'

return service
