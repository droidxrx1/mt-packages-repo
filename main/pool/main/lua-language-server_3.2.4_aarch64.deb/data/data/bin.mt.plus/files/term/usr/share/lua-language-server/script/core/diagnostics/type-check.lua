---@async
return function(uri, callback)
end
