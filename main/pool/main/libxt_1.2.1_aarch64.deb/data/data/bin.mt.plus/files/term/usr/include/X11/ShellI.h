#ifndef _XtShellInternal_h
#define _XtShellInternal_h

#include <X11/Xfuncproto.h>

_XFUNCPROTOBEGIN

extern void _XtShellGetCoordinates(Widget widget, Position *x, Position *y);

#endif /* _XtShellInternal_h */
